﻿using System;
using System.Numerics; 
using System.Windows;

namespace FactorialApp
{
    public partial class MainWindow : Window
    {
        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            string input = InputTextBox.Text;

            if (string.IsNullOrEmpty(input))
            {
                ResultTextBlock.Text = "Ошибка: Введите число!";
                return;
            }

            int number;
            try
            {
                number = int.Parse(input);
            }
            catch (FormatException)
            {
                ResultTextBlock.Text = "Ошибка: Некорректный ввод!";
                return;
            }

            if (number < 0)
            {
                ResultTextBlock.Text = "Ошибка: Число должно быть неотрицательным!";
                return;
            }

            try
            {
                BigInteger factorial = CalculateFactorial(number);
                ResultTextBlock.Text = $"Факториал: {factorial}";
            }
            catch (OverflowException)
            {
                ResultTextBlock.Text = "Ошибка: Переполнение!";
            }
        }

        private BigInteger CalculateFactorial(int n)
        {
            BigInteger result = BigInteger.One;
            for (int i = 1; i <= n; i++)
            {
                result *= i;
            }
            return result;
        }
    }
}